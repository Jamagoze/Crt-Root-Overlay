package com.crt.overlay;

import android.app.Activity;
import android.content.*;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.*;

public class MainActivity extends Activity {
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences(OverlayService.PREFS, MODE_PRIVATE);
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 0);
        }

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (24 * getResources().getDisplayMetrics().density);
        root.setPadding(pad, pad, pad, pad);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        scroll.addView(root);

        addSlider(root, "Scanline strength", "scan", 40);
        addSlider(root, "Red/blue 3D fringe", "rb", 30);
        addSlider(root, "Bloom (glow)", "bloom", 30);
        addSlider(root, "Vignette", "vig", 30);

        Switch moving = new Switch(this);
        moving.setText("Moving scanlines");
        moving.setChecked(prefs.getBoolean("moving", false));
        moving.setOnCheckedChangeListener((v, on) -> {
            prefs.edit().putBoolean("moving", on).apply();
            refresh();
        });
        root.addView(moving);

        addSlider(root, "Scroll speed", "speed", 30);

        Button start = new Button(this);
        start.setText("Start overlay");
        start.setOnClickListener(v -> startOverlay());
        root.addView(start);

        Button stop = new Button(this);
        stop.setText("Stop overlay");
        stop.setOnClickListener(v -> stopService(new Intent(this, OverlayService.class)));
        root.addView(stop);

        setContentView(scroll);
    }

    private void addSlider(LinearLayout parent, String name, String key, int def) {
        TextView tv = new TextView(this);
        tv.setText(name);
        parent.addView(tv);
        SeekBar s = new SeekBar(this);
        s.setMax(100);
        s.setProgress(prefs.getInt(key, def));
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar sb, int p, boolean user) {
                if (!user) return;
                prefs.edit().putInt(key, p).apply();
                refresh();
            }
            public void onStartTrackingTouch(SeekBar sb) {}
            public void onStopTrackingTouch(SeekBar sb) {}
        });
        parent.addView(s);
    }

    private void refresh() {
        if (Settings.canDrawOverlays(this) && OverlayRunning.is) startOverlay();
    }

    private void startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
            return;
        }
        OverlayRunning.is = true;
        startForegroundService(new Intent(this, OverlayService.class));
    }

    /** Tracks whether we've started the overlay so sliders only live-update a running one. */
    static class OverlayRunning { static boolean is = false; }
}
