package com.crt.overlay;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.*;

public class OverlayService extends Service {
    public static final String PREFS = "crt";
    private WindowManager wm;
    private CrtView view;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForegroundCompat();
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        int scan = p.getInt("scan", 40);
        int vig = p.getInt("vig", 30);
        int bloom = p.getInt("bloom", 30);
        int rb = p.getInt("rb", 30);
        int speed = p.getInt("speed", 30);
        boolean moving = p.getBoolean("moving", false);

        if (view == null) {
            wm = (WindowManager) getSystemService(WINDOW_SERVICE);
            view = new CrtView(this);

            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT);
            // Android 12+ only lets touches pass through overlays with alpha <= 0.8
            lp.alpha = 0.8f;
            if (Build.VERSION.SDK_INT >= 28) {
                lp.layoutInDisplayCutoutMode =
                        WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
            }
            wm.addView(view, lp);
        }
        view.setStrengths(scan, vig, bloom, rb, moving, speed);
        return START_STICKY;
    }

    private void startForegroundCompat() {
        String ch = "crt_overlay";
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(ch, "CRT Overlay",
                NotificationManager.IMPORTANCE_LOW));
        Notification n = new Notification.Builder(this, ch)
                .setContentTitle("CRT overlay active")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentIntent(PendingIntent.getActivity(this, 0,
                        new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE))
                .build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(1, n);
        }
    }

    @Override
    public void onDestroy() {
        if (view != null && wm != null) wm.removeView(view);
        view = null;
        MainActivity.OverlayRunning.is = false;
        super.onDestroy();
    }
}
