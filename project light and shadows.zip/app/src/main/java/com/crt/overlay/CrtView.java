package com.crt.overlay;

import android.content.Context;
import android.graphics.*;
import android.view.View;

public class CrtView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Matrix matrix = new Matrix();
    private Bitmap tile;
    private BitmapShader tileShader;
    private final int tileH;

    private int scan = 40, vig = 30, bloom = 30, rb = 30, speed = 30;
    private boolean moving = false;
    private long startNs = System.nanoTime();

    public CrtView(Context c) {
        super(c);
        tileH = Math.max(4, Math.round(getResources().getDisplayMetrics().density * 2f));
        rebuildTile();
    }

    public void setStrengths(int scan, int vig, int bloom, int rb, boolean moving, int speed) {
        this.scan = scan; this.vig = vig; this.bloom = bloom; this.rb = rb;
        this.moving = moving; this.speed = speed;
        rebuildTile();
        invalidate();
    }

    private static int a(int pct, float max) {
        return Math.min(255, Math.round(pct * 2.55f * max));
    }

    // 1px-wide tile: one dark line, plus red and blue lines for the 3D fringe
    private void rebuildTile() {
        if (tile != null) tile.recycle();
        tile = Bitmap.createBitmap(1, tileH, Bitmap.Config.ARGB_8888);
        tile.eraseColor(Color.TRANSPARENT);
        tile.setPixel(0, 0, Color.argb(a(scan, 1f), 0, 0, 0));
        if (rb > 0) {
            tile.setPixel(0, tileH / 2, Color.argb(a(rb, 0.5f), 255, 0, 0));
            tile.setPixel(0, Math.min(tileH - 1, tileH / 2 + 1), Color.argb(a(rb, 0.5f), 0, 80, 255));
        }
        tileShader = new BitmapShader(tile, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth(), h = getHeight();
        if (w == 0 || h == 0) return;

        float t = (System.nanoTime() - startNs) / 1e9f;

        // Scanlines (optionally scrolling)
        float offset = 0f;
        if (moving) offset = (t * (20f + speed * 4f)) % tileH;
        matrix.setTranslate(0, offset);
        tileShader.setLocalMatrix(matrix);
        paint.setShader(tileShader);
        canvas.drawRect(0, 0, w, h, paint);

        // Slow rolling dark band while moving
        if (moving && scan > 0) {
            float bandH = h * 0.22f;
            float y = ((t * (h * (0.05f + speed / 400f))) % (h + bandH)) - bandH;
            paint.setShader(new LinearGradient(0, y, 0, y + bandH,
                    new int[]{Color.TRANSPARENT, Color.argb(a(scan, 0.35f), 0, 0, 0), Color.TRANSPARENT},
                    null, Shader.TileMode.CLAMP));
            canvas.drawRect(0, y, w, y + bandH, paint);
        }

        // Red / blue 3D fringe on the left and right edges
        if (rb > 0) {
            float edge = w * 0.18f;
            paint.setShader(new LinearGradient(0, 0, edge, 0,
                    Color.argb(a(rb, 0.6f), 255, 0, 0), Color.TRANSPARENT, Shader.TileMode.CLAMP));
            canvas.drawRect(0, 0, edge, h, paint);
            paint.setShader(new LinearGradient(w, 0, w - edge, 0,
                    Color.argb(a(rb, 0.6f), 0, 90, 255), Color.TRANSPARENT, Shader.TileMode.CLAMP));
            canvas.drawRect(w - edge, 0, w, h, paint);
        }

        // Bloom: warm glow wash, brightest in the centre
        if (bloom > 0) {
            float radius = (float) Math.hypot(w, h) / 2f;
            paint.setShader(new RadialGradient(w / 2f, h / 2f, radius,
                    new int[]{Color.argb(a(bloom, 0.30f), 255, 244, 230),
                              Color.argb(a(bloom, 0.12f), 255, 240, 225),
                              Color.TRANSPARENT},
                    new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
            canvas.drawRect(0, 0, w, h, paint);
        }

        // Vignette
        if (vig > 0) {
            float radius = (float) Math.hypot(w, h) / 2f;
            paint.setShader(new RadialGradient(w / 2f, h / 2f, radius,
                    new int[]{Color.TRANSPARENT, Color.TRANSPARENT, Color.argb(a(vig, 1f), 0, 0, 0)},
                    new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
            canvas.drawRect(0, 0, w, h, paint);
        }

        if (moving) postInvalidateOnAnimation();
    }
}
