#pragma once
#include <string>
#include <EGL/egl.h>

void crt_config(const std::string& text);
void crt_process(EGLDisplay dpy, EGLSurface surf);
