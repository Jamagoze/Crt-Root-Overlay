#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

NDK="${ANDROID_NDK_LATEST_HOME:-${ANDROID_NDK_HOME:-${ANDROID_NDK_ROOT:-}}}"
[ -n "$NDK" ] || { echo "Android NDK not found"; exit 1; }

if [ ! -f src/zygisk.hpp ]; then
  curl -fsSL https://raw.githubusercontent.com/topjohnwu/zygisk-module-sample/master/module/jni/zygisk.hpp -o src/zygisk.hpp
fi

rm -rf out pkg
mkdir -p out pkg/zygisk ../dist
cp -r module/. pkg/

for abi in arm64-v8a armeabi-v7a; do
  cmake -S . -B "out/$abi" \
    -DCMAKE_TOOLCHAIN_FILE="$NDK/build/cmake/android.toolchain.cmake" \
    -DANDROID_ABI="$abi" -DANDROID_PLATFORM=android-26 \
    -DANDROID_STL=c++_static -DCMAKE_BUILD_TYPE=Release
  cmake --build "out/$abi" -j"$(nproc)"
  cp "out/$abi/libcrt3d.so" "pkg/zygisk/$abi.so"
done

rm -f ../dist/crt3d-zygisk.zip
(cd pkg && zip -r9 ../../dist/crt3d-zygisk.zip .)
