ui_print "- Installing CRT 3D"
mkdir -p /data/adb/crt3d
[ -f /data/adb/crt3d/apps.txt ] || cp "$MODPATH/apps.txt" /data/adb/crt3d/apps.txt
[ -f /data/adb/crt3d/config.txt ] || cp "$MODPATH/config.txt" /data/adb/crt3d/config.txt
set_perm_recursive "$MODPATH" 0 0 0755 0644
ui_print "- Edit /data/adb/crt3d/apps.txt to choose games"
ui_print "- Needs Zygisk enabled; game must not be in the DenyList"
