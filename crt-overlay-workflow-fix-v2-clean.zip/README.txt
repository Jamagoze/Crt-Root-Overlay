CRT Overlay GitHub Actions workflow fix

Install:
1. Extract this ZIP.
2. Upload/replace .github/workflows/build.yml in your GitHub repository.
3. Commit the workflow.
4. Upload your Android source ZIP to the repository root.
5. Open Actions. The workflow triggers when a ZIP is pushed, or use Run workflow.
6. If multiple ZIPs are in the repository, run manually and enter the exact filename in source_zip.
7. Download the individual APKs from the completed run's Artifacts section.

The workflow extracts the source ZIP first, locates settings.gradle, sets up Java 17,
Android SDK and Gradle 8.7, then builds assembleDebug and assembleRelease.
