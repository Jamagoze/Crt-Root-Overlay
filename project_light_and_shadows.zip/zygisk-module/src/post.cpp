#include "post.h"
#include <GLES2/gl2.h>
#include <android/log.h>
#include <algorithm>
#include <cstdlib>
#include <cmath>
#include <cstring>
#include <ctime>
#include <mutex>
#include <sstream>
#include <unordered_map>

#define TAG "CRT3D"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

namespace {

struct Cfg {
    bool anaglyph = true;
    float sep = 0.005f, depth = 0.5f, bloom = 0.8f, thr = 0.6f, radius = 1.0f;
    // Lights And Shadows
    bool lights = false, dayWhite = false;
    float lightInt = 0.25f, moonInt = 0.15f;
    float shadow = 0.35f, shadowThr = 0.5f, shadowLen = 0.015f;
    int shadowBlur = 3;
    float hour = -1.0f;  // <0 = use the device clock
} cfg;

const char* VS =
    "attribute vec2 aPos; varying vec2 vUv;"
    "void main(){ vUv = aPos*0.5+0.5; gl_Position = vec4(aPos,0.0,1.0); }";

#define FS_HEAD "#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\nvarying vec2 vUv;\n"

const char* FS_BRIGHT = FS_HEAD
    "uniform sampler2D uTex; uniform float uThr;"
    "void main(){ vec3 c = texture2D(uTex,vUv).rgb;"
    " float l = max(max(c.r,c.g),c.b);"
    " float k = max(l-uThr,0.0)/max(l,0.0001);"
    " gl_FragColor = vec4(c*k,1.0); }";

const char* FS_BLUR = FS_HEAD
    "uniform sampler2D uTex; uniform vec2 uDir;"
    "void main(){ vec3 s = texture2D(uTex,vUv).rgb*0.227027;"
    " s += (texture2D(uTex,vUv+uDir).rgb + texture2D(uTex,vUv-uDir).rgb)*0.1945946;"
    " s += (texture2D(uTex,vUv+uDir*2.0).rgb + texture2D(uTex,vUv-uDir*2.0).rgb)*0.1216216;"
    " s += (texture2D(uTex,vUv+uDir*3.0).rgb + texture2D(uTex,vUv-uDir*3.0).rgb)*0.054054;"
    " s += (texture2D(uTex,vUv+uDir*4.0).rgb + texture2D(uTex,vUv-uDir*4.0).rgb)*0.016216;"
    " gl_FragColor = vec4(s,1.0); }";

const char* FS_MASK = FS_HEAD
    "uniform sampler2D uTex; uniform float uM;"
    "void main(){ float b = texture2D(uTex,vUv).b;"
    " float a = (b < uM) ? pow(max(1.0-b,0.0),0.75) : 0.0;"
    " gl_FragColor = vec4(a,a,a,1.0); }";

const char* FS_KAWASE = FS_HEAD
    "uniform sampler2D uTex; uniform vec2 uOff;"
    "void main(){ vec3 s = texture2D(uTex,vUv+uOff).rgb + texture2D(uTex,vUv-uOff).rgb"
    " + texture2D(uTex,vUv+vec2(uOff.x,-uOff.y)).rgb + texture2D(uTex,vUv+vec2(-uOff.x,uOff.y)).rgb;"
    " gl_FragColor = vec4(s*0.25,1.0); }";

const char* FS_FINAL = FS_HEAD
    "uniform sampler2D uScene; uniform sampler2D uB0; uniform sampler2D uB1; uniform sampler2D uSh;"
    "uniform float uSep; uniform float uDepth; uniform float uBloom; uniform float uAna;"
    "uniform float uShInt; uniform vec2 uShOff; uniform vec3 uLCol; uniform vec2 uLPos; uniform float uAsp;"
    "vec3 src(vec2 uv){ vec3 c = texture2D(uScene,uv).rgb;"
    " if (uShInt > 0.0) c *= 1.0 - uShInt*texture2D(uSh,uv-uShOff).r;"
    " vec2 d = (uv-uLPos)*vec2(uAsp,1.0);"
    " c += uLCol*max((3.0-length(d))/3.0,0.0);"
    " return c + (texture2D(uB0,uv).rgb*0.7 + texture2D(uB1,uv).rgb*0.9)*uBloom; }"
    "void main(){ vec3 c = src(vUv); vec3 o = c;"
    " if (uAna > 0.5) {"
    "   float lum = dot(c, vec3(0.299,0.587,0.114));"
    "   float s = uSep*(1.0 + uDepth*(lum*2.0-1.0));"
    "   vec3 l = src(vUv - vec2(s,0.0));"
    "   vec3 r = src(vUv + vec2(s,0.0));"
    "   o = vec3(l.r, r.g, r.b);"
    " }"
    " gl_FragColor = vec4(o,1.0); }";

struct Res {
    bool failed = false, ready = false;
    GLuint pBright = 0, pBlur = 0, pFinal = 0, pMask = 0, pKawase = 0, vbo = 0, texScene = 0;
    GLuint texS[2] = {0, 0}, fboS[2] = {0, 0};
    GLint uMkTex = -1, uMkM = -1, uKwTex = -1, uKwOff = -1;
    GLint uFSh = -1, uFShInt = -1, uFShOff = -1, uFLCol = -1, uFLPos = -1, uFAsp = -1;
    GLuint texA[2] = {0, 0}, texB[2] = {0, 0}, fboA[2] = {0, 0}, fboB[2] = {0, 0};
    int w = 0, h = 0, bw[2] = {0, 0}, bh[2] = {0, 0};
    GLint uBrTex = -1, uBrThr = -1, uBlTex = -1, uBlDir = -1;
    GLint uFScene = -1, uFB0 = -1, uFB1 = -1, uFSep = -1, uFDepth = -1, uFBloom = -1, uFAna = -1;
};

std::mutex g_mu;
std::unordered_map<EGLContext, Res> g_res;
typedef void (*BindVaoFn)(GLuint);
BindVaoFn g_bindVao = nullptr;
bool g_vaoResolved = false;

GLuint compile(GLenum type, const char* src) {
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, nullptr);
    glCompileShader(s);
    GLint ok = 0;
    glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char buf[512];
        glGetShaderInfoLog(s, sizeof(buf), nullptr, buf);
        LOGE("shader compile failed: %s", buf);
        glDeleteShader(s);
        return 0;
    }
    return s;
}

GLuint linkProg(const char* vs, const char* fs) {
    GLuint v = compile(GL_VERTEX_SHADER, vs);
    GLuint f = compile(GL_FRAGMENT_SHADER, fs);
    if (!v || !f) return 0;
    GLuint p = glCreateProgram();
    glAttachShader(p, v);
    glAttachShader(p, f);
    glBindAttribLocation(p, 0, "aPos");
    glLinkProgram(p);
    GLint ok = 0;
    glGetProgramiv(p, GL_LINK_STATUS, &ok);
    if (!ok) {
        char buf[512];
        glGetProgramInfoLog(p, sizeof(buf), nullptr, buf);
        LOGE("program link failed: %s", buf);
        return 0;
    }
    return p;
}

GLuint makeTex(int w, int h, GLenum fmt) {
    GLuint t = 0;
    glGenTextures(1, &t);
    glBindTexture(GL_TEXTURE_2D, t);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexImage2D(GL_TEXTURE_2D, 0, fmt, w, h, 0, fmt, GL_UNSIGNED_BYTE, nullptr);
    return t;
}

GLuint makeFbo(GLuint tex) {
    GLuint f = 0;
    glGenFramebuffers(1, &f);
    glBindFramebuffer(GL_FRAMEBUFFER, f);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, tex, 0);
    return f;
}

void freeTargets(Res& r) {
    if (r.texScene) glDeleteTextures(1, &r.texScene);
    r.texScene = 0;
    for (int i = 0; i < 2; i++) {
        if (r.texS[i]) glDeleteTextures(1, &r.texS[i]);
        if (r.fboS[i]) glDeleteFramebuffers(1, &r.fboS[i]);
        r.texS[i] = r.fboS[i] = 0;
        if (r.texA[i]) glDeleteTextures(1, &r.texA[i]);
        if (r.texB[i]) glDeleteTextures(1, &r.texB[i]);
        if (r.fboA[i]) glDeleteFramebuffers(1, &r.fboA[i]);
        if (r.fboB[i]) glDeleteFramebuffers(1, &r.fboB[i]);
        r.texA[i] = r.texB[i] = r.fboA[i] = r.fboB[i] = 0;
    }
}

bool buildTargets(Res& r, int W, int H) {
    freeTargets(r);
    r.w = W;
    r.h = H;
    glActiveTexture(GL_TEXTURE0);
    r.texScene = makeTex(W, H, GL_RGB);
    const int div[2] = {4, 8};
    for (int i = 0; i < 2; i++) {
        r.bw[i] = std::max(1, W / div[i]);
        r.bh[i] = std::max(1, H / div[i]);
        r.texA[i] = makeTex(r.bw[i], r.bh[i], GL_RGBA);
        r.texB[i] = makeTex(r.bw[i], r.bh[i], GL_RGBA);
        r.fboA[i] = makeFbo(r.texA[i]);
        if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE) return false;
        r.fboB[i] = makeFbo(r.texB[i]);
        if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE) return false;
    }
    for (int i = 0; i < 2; i++) {
        r.texS[i] = makeTex(r.bw[0], r.bh[0], GL_RGBA);
        r.fboS[i] = makeFbo(r.texS[i]);
        if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE) return false;
    }
    return glGetError() == GL_NO_ERROR;
}

bool initRes(Res& r) {
    r.pBright = linkProg(VS, FS_BRIGHT);
    r.pBlur = linkProg(VS, FS_BLUR);
    r.pFinal = linkProg(VS, FS_FINAL);
    r.pMask = linkProg(VS, FS_MASK);
    r.pKawase = linkProg(VS, FS_KAWASE);
    if (!r.pBright || !r.pBlur || !r.pFinal || !r.pMask || !r.pKawase) return false;
    r.uMkTex = glGetUniformLocation(r.pMask, "uTex");
    r.uMkM = glGetUniformLocation(r.pMask, "uM");
    r.uKwTex = glGetUniformLocation(r.pKawase, "uTex");
    r.uKwOff = glGetUniformLocation(r.pKawase, "uOff");
    r.uFSh = glGetUniformLocation(r.pFinal, "uSh");
    r.uFShInt = glGetUniformLocation(r.pFinal, "uShInt");
    r.uFShOff = glGetUniformLocation(r.pFinal, "uShOff");
    r.uFLCol = glGetUniformLocation(r.pFinal, "uLCol");
    r.uFLPos = glGetUniformLocation(r.pFinal, "uLPos");
    r.uFAsp = glGetUniformLocation(r.pFinal, "uAsp");
    r.uBrTex = glGetUniformLocation(r.pBright, "uTex");
    r.uBrThr = glGetUniformLocation(r.pBright, "uThr");
    r.uBlTex = glGetUniformLocation(r.pBlur, "uTex");
    r.uBlDir = glGetUniformLocation(r.pBlur, "uDir");
    r.uFScene = glGetUniformLocation(r.pFinal, "uScene");
    r.uFB0 = glGetUniformLocation(r.pFinal, "uB0");
    r.uFB1 = glGetUniformLocation(r.pFinal, "uB1");
    r.uFSep = glGetUniformLocation(r.pFinal, "uSep");
    r.uFDepth = glGetUniformLocation(r.pFinal, "uDepth");
    r.uFBloom = glGetUniformLocation(r.pFinal, "uBloom");
    r.uFAna = glGetUniformLocation(r.pFinal, "uAna");
    static const GLfloat quad[8] = {-1, -1, 1, -1, -1, 1, 1, 1};
    glGenBuffers(1, &r.vbo);
    glBindBuffer(GL_ARRAY_BUFFER, r.vbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(quad), quad, GL_STATIC_DRAW);
    return glGetError() == GL_NO_ERROR;
}

void bindTex(int unit, GLuint tex) {
    glActiveTexture(GL_TEXTURE0 + unit);
    glBindTexture(GL_TEXTURE_2D, tex);
}

void drawTo(GLuint fbo, int vw, int vh) {
    glBindFramebuffer(GL_FRAMEBUFFER, fbo);
    glViewport(0, 0, vw, vh);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
}

struct LightState {
    float pos[2] = {0.5f, 1.0f};
    float col[3] = {0, 0, 0};
};

float lerpf(float a, float b, float t) { return a + (b - a) * t; }

// Sun/moon position and colour from the time of day (same idea as the tModLoader mod:
// sun arcs over the screen, warm at dawn/dusk, yellow or white at noon, pale blue moon at night)
LightState computeLight() {
    LightState L;
    float h = cfg.hour;
    if (h < 0.0f) {
        time_t t = time(nullptr);
        struct tm lt;
        localtime_r(&t, &lt);
        h = lt.tm_hour + lt.tm_min / 60.0f + lt.tm_sec / 3600.0f;
    }
    const bool day = h >= 4.5f && h < 19.5f;
    float t = day ? (h - 4.5f) / 15.0f : ((h >= 19.5f ? h - 19.5f : h + 4.5f) / 9.0f);
    if (t < 0.0f) t = 0.0f;
    if (t > 1.0f) t = 1.0f;
    const float edge = std::min(1.0f, std::min(t, 1.0f - t) * 8.0f);
    L.pos[0] = 0.1f + 0.8f * t;
    L.pos[1] = 0.55f + 0.45f * sinf(3.14159265f * t);
    float c[3];
    float k;
    if (day) {
        static const float key[5][3] = {{1.0f, 0.55f, 0.30f}, {1.0f, 0.85f, 0.55f}, {1.0f, 0.92f, 0.60f},
                                        {1.0f, 0.80f, 0.50f}, {1.0f, 0.45f, 0.25f}};
        float f = t * 4.0f;
        int i = std::min(3, (int)f);
        float u = f - i;
        for (int j = 0; j < 3; j++) c[j] = lerpf(key[i][j], key[i + 1][j], u);
        if (cfg.dayWhite) {
            float w = 1.0f - fabsf(t - 0.5f) * 2.0f;  // 1 at noon
            for (int j = 0; j < 3; j++) c[j] = lerpf(c[j], 1.0f, w);
        }
        k = cfg.lightInt * edge;
    } else {
        c[0] = 0.35f; c[1] = 0.45f; c[2] = 0.85f;
        k = cfg.moonInt * edge;
    }
    for (int j = 0; j < 3; j++) L.col[j] = c[j] * k;
    return L;
}

void doProcess(EGLDisplay dpy, EGLSurface surf) {
    EGLContext ctx = eglGetCurrentContext();
    if (ctx == EGL_NO_CONTEXT || eglGetCurrentSurface(EGL_DRAW) != surf) return;
    EGLint W = 0, H = 0;
    eglQuerySurface(dpy, surf, EGL_WIDTH, &W);
    eglQuerySurface(dpy, surf, EGL_HEIGHT, &H);
    if (W < 128 || H < 128) return;
    const bool useBloom = cfg.bloom > 0.001f;
    const bool useShadow = cfg.lights && cfg.shadow > 0.001f;
    if (!cfg.anaglyph && !useBloom && !cfg.lights) return;

    std::lock_guard<std::mutex> lk(g_mu);
    Res& r = g_res[ctx];
    if (r.failed) return;

    while (glGetError() != GL_NO_ERROR) {}

    const char* ver = (const char*)glGetString(GL_VERSION);
    const bool es3 = ver && strstr(ver, "OpenGL ES 3");
    if (es3 && !g_vaoResolved) {
        g_bindVao = (BindVaoFn)eglGetProcAddress("glBindVertexArray");
        g_vaoResolved = true;
    }
    const bool useVao = es3 && g_bindVao;

    // ---- save app GL state ----
    GLint prog = 0, arr = 0, drawFb = 0, readFb = 0, vp[4] = {0, 0, 0, 0}, act = 0, vao = 0;
    GLint tb[4] = {0, 0, 0, 0};
    GLboolean cm[4];
    glGetIntegerv(GL_CURRENT_PROGRAM, &prog);
    glGetIntegerv(GL_ARRAY_BUFFER_BINDING, &arr);
    glGetIntegerv(0x8CA6, &drawFb);
    readFb = drawFb;
    if (es3) glGetIntegerv(0x8CAA, &readFb);
    glGetIntegerv(GL_VIEWPORT, vp);
    glGetIntegerv(GL_ACTIVE_TEXTURE, &act);
    for (int i = 0; i < 4; i++) {
        glActiveTexture(GL_TEXTURE0 + i);
        glGetIntegerv(GL_TEXTURE_BINDING_2D, &tb[i]);
    }
    glGetBooleanv(GL_COLOR_WRITEMASK, cm);
    const GLboolean eBl = glIsEnabled(GL_BLEND), eDe = glIsEnabled(GL_DEPTH_TEST),
                    eSt = glIsEnabled(GL_STENCIL_TEST), eSc = glIsEnabled(GL_SCISSOR_TEST),
                    eCu = glIsEnabled(GL_CULL_FACE), eDi = glIsEnabled(GL_DITHER);
    if (useVao) {
        glGetIntegerv(0x85B5, &vao);
        g_bindVao(0);
    }
    GLint a0en = 0, a0sz = 4, a0ty = GL_FLOAT, a0nm = 0, a0st = 0, a0bf = 0;
    void* a0ptr = nullptr;
    glGetVertexAttribiv(0, GL_VERTEX_ATTRIB_ARRAY_ENABLED, &a0en);
    glGetVertexAttribiv(0, GL_VERTEX_ATTRIB_ARRAY_SIZE, &a0sz);
    glGetVertexAttribiv(0, GL_VERTEX_ATTRIB_ARRAY_TYPE, &a0ty);
    glGetVertexAttribiv(0, GL_VERTEX_ATTRIB_ARRAY_NORMALIZED, &a0nm);
    glGetVertexAttribiv(0, GL_VERTEX_ATTRIB_ARRAY_STRIDE, &a0st);
    glGetVertexAttribiv(0, GL_VERTEX_ATTRIB_ARRAY_BUFFER_BINDING, &a0bf);
    glGetVertexAttribPointerv(0, GL_VERTEX_ATTRIB_ARRAY_POINTER, &a0ptr);
    while (glGetError() != GL_NO_ERROR) {}

    // ---- our passes ----
    bool ok = [&]() -> bool {
        if (!r.ready) {
            if (!initRes(r)) return false;
            r.ready = true;
            LOGI("initialised %dx%d (es3=%d)", W, H, (int)es3);
        }
        if (r.w != W || r.h != H) {
            if (!buildTargets(r, W, H)) return false;
        }
        glDisable(GL_BLEND);
        glDisable(GL_DEPTH_TEST);
        glDisable(GL_STENCIL_TEST);
        glDisable(GL_SCISSOR_TEST);
        glDisable(GL_CULL_FACE);
        glDisable(GL_DITHER);
        glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
        glBindBuffer(GL_ARRAY_BUFFER, r.vbo);
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 0, (const void*)0);

        // copy the finished frame
        glBindFramebuffer(GL_FRAMEBUFFER, 0);
        bindTex(0, r.texScene);
        glCopyTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, 0, 0, W, H);
        if (glGetError() != GL_NO_ERROR) return false;

        if (useBloom) {
            // level 0 (1/4 res): bright pass + blur
            glUseProgram(r.pBright);
            glUniform1i(r.uBrTex, 0);
            glUniform1f(r.uBrThr, cfg.thr);
            bindTex(0, r.texScene);
            drawTo(r.fboA[0], r.bw[0], r.bh[0]);

            glUseProgram(r.pBlur);
            glUniform1i(r.uBlTex, 0);
            bindTex(0, r.texA[0]);
            glUniform2f(r.uBlDir, cfg.radius / r.bw[0], 0.0f);
            drawTo(r.fboB[0], r.bw[0], r.bh[0]);
            bindTex(0, r.texB[0]);
            glUniform2f(r.uBlDir, 0.0f, cfg.radius / r.bh[0]);
            drawTo(r.fboA[0], r.bw[0], r.bh[0]);

            // level 1 (1/8 res): downsample + blur for the wide halo
            glUseProgram(r.pBright);
            glUniform1i(r.uBrTex, 0);
            glUniform1f(r.uBrThr, 0.0f);
            bindTex(0, r.texA[0]);
            drawTo(r.fboA[1], r.bw[1], r.bh[1]);

            glUseProgram(r.pBlur);
            glUniform1i(r.uBlTex, 0);
            bindTex(0, r.texA[1]);
            glUniform2f(r.uBlDir, cfg.radius * 1.5f / r.bw[1], 0.0f);
            drawTo(r.fboB[1], r.bw[1], r.bh[1]);
            bindTex(0, r.texB[1]);
            glUniform2f(r.uBlDir, 0.0f, cfg.radius * 1.5f / r.bh[1]);
            drawTo(r.fboA[1], r.bw[1], r.bh[1]);
        }

        // shadow mask (dark-blue pixels) + Kawase blur at 1/4 res
        GLuint shTex = r.texScene;
        if (useShadow) {
            glUseProgram(r.pMask);
            glUniform1i(r.uMkTex, 0);
            glUniform1f(r.uMkM, cfg.shadowThr);
            bindTex(0, r.texScene);
            drawTo(r.fboS[0], r.bw[0], r.bh[0]);
            glUseProgram(r.pKawase);
            glUniform1i(r.uKwTex, 0);
            int cur = 0;
            const int n = std::max(1, std::min(cfg.shadowBlur, 6));
            for (int i = 0; i < n; i++) {
                bindTex(0, r.texS[cur]);
                glUniform2f(r.uKwOff, (i + 0.5f) / r.bw[0], (i + 0.5f) / r.bh[0]);
                drawTo(r.fboS[1 - cur], r.bw[0], r.bh[0]);
                cur = 1 - cur;
            }
            shTex = r.texS[cur];
        }

        // light + shadow direction
        LightState L;
        float shOffX = 0.0f, shOffY = 0.0f;
        const float asp = (float)W / (float)H;
        if (cfg.lights) {
            L = computeLight();
            float dx = (0.5f - L.pos[0]) * asp, dy = 0.5f - L.pos[1];
            float len = sqrtf(dx * dx + dy * dy);
            if (len < 0.0001f) { dx = 0.0f; dy = -1.0f; len = 1.0f; }
            shOffX = dx / len / asp * cfg.shadowLen;
            shOffY = dy / len * cfg.shadowLen;
        }

        // final composite straight onto the screen buffer
        glUseProgram(r.pFinal);
        bindTex(3, shTex);
        glUniform1i(r.uFSh, 3);
        glUniform1f(r.uFShInt, useShadow ? cfg.shadow : 0.0f);
        glUniform2f(r.uFShOff, shOffX, shOffY);
        glUniform3f(r.uFLCol, L.col[0], L.col[1], L.col[2]);
        glUniform2f(r.uFLPos, L.pos[0], L.pos[1]);
        glUniform1f(r.uFAsp, asp);
        bindTex(0, r.texScene);
        bindTex(1, useBloom ? r.texA[0] : r.texScene);
        bindTex(2, useBloom ? r.texA[1] : r.texScene);
        glUniform1i(r.uFScene, 0);
        glUniform1i(r.uFB0, 1);
        glUniform1i(r.uFB1, 2);
        glUniform1f(r.uFSep, cfg.sep);
        glUniform1f(r.uFDepth, cfg.depth);
        glUniform1f(r.uFBloom, useBloom ? cfg.bloom : 0.0f);
        glUniform1f(r.uFAna, cfg.anaglyph ? 1.0f : 0.0f);
        drawTo(0, W, H);
        return glGetError() == GL_NO_ERROR;
    }();

    if (!ok) {
        r.failed = true;
        LOGE("post-process disabled for this context (GL error or unsupported)");
    }

    // ---- restore app GL state ----
    glBindBuffer(GL_ARRAY_BUFFER, a0bf);
    glVertexAttribPointer(0, a0sz, a0ty, (GLboolean)a0nm, a0st, a0ptr);
    if (a0en) glEnableVertexAttribArray(0); else glDisableVertexAttribArray(0);
    if (useVao) g_bindVao(vao);
    glBindBuffer(GL_ARRAY_BUFFER, arr);
    if (es3) {
        glBindFramebuffer(0x8CA8, readFb);
        glBindFramebuffer(0x8CA9, drawFb);
    } else {
        glBindFramebuffer(GL_FRAMEBUFFER, drawFb);
    }
    glViewport(vp[0], vp[1], vp[2], vp[3]);
    glUseProgram(prog);
    for (int i = 0; i < 4; i++) {
        glActiveTexture(GL_TEXTURE0 + i);
        glBindTexture(GL_TEXTURE_2D, tb[i]);
    }
    glActiveTexture(act);
    glColorMask(cm[0], cm[1], cm[2], cm[3]);
    if (eBl) glEnable(GL_BLEND); else glDisable(GL_BLEND);
    if (eDe) glEnable(GL_DEPTH_TEST); else glDisable(GL_DEPTH_TEST);
    if (eSt) glEnable(GL_STENCIL_TEST); else glDisable(GL_STENCIL_TEST);
    if (eSc) glEnable(GL_SCISSOR_TEST); else glDisable(GL_SCISSOR_TEST);
    if (eCu) glEnable(GL_CULL_FACE); else glDisable(GL_CULL_FACE);
    if (eDi) glEnable(GL_DITHER); else glDisable(GL_DITHER);
    while (glGetError() != GL_NO_ERROR) {}
}

}  // namespace

void crt_config(const std::string& text) {
    std::istringstream in(text);
    std::string line;
    while (std::getline(in, line)) {
        line.erase(std::remove(line.begin(), line.end(), '\r'), line.end());
        size_t b = line.find_first_not_of(" \t");
        if (b == std::string::npos || line[b] == '#') continue;
        size_t eq = line.find('=');
        if (eq == std::string::npos) continue;
        std::string k = line.substr(b, eq - b);
        std::string v = line.substr(eq + 1);
        while (!k.empty() && (k.back() == ' ' || k.back() == '\t')) k.pop_back();
        float f = (float)atof(v.c_str());
        if (k == "anaglyph") cfg.anaglyph = f != 0.0f;
        else if (k == "separation") cfg.sep = f;
        else if (k == "depth") cfg.depth = f;
        else if (k == "bloom") cfg.bloom = f;
        else if (k == "threshold") cfg.thr = f;
        else if (k == "radius") cfg.radius = f;
        else if (k == "lights") cfg.lights = f != 0.0f;
        else if (k == "light_intensity") cfg.lightInt = f;
        else if (k == "moon_intensity") cfg.moonInt = f;
        else if (k == "day_white") cfg.dayWhite = f != 0.0f;
        else if (k == "shadow") cfg.shadow = f;
        else if (k == "shadow_threshold") cfg.shadowThr = f;
        else if (k == "shadow_length") cfg.shadowLen = f;
        else if (k == "shadow_blur") cfg.shadowBlur = (int)f;
        else if (k == "hour") cfg.hour = f;
    }
    LOGI("config: anaglyph=%d sep=%.4f depth=%.2f bloom=%.2f thr=%.2f radius=%.2f lights=%d shadow=%.2f",
         (int)cfg.anaglyph, cfg.sep, cfg.depth, cfg.bloom, cfg.thr, cfg.radius, (int)cfg.lights, cfg.shadow);
}

void crt_process(EGLDisplay dpy, EGLSurface surf) {
    static thread_local bool busy = false;
    if (busy) return;
    busy = true;
    doProcess(dpy, surf);
    busy = false;
}
