#include <EGL/egl.h>
#include <android/log.h>
#include <jni.h>
#include <link.h>
#include <pthread.h>
#include <sys/mman.h>
#include <unistd.h>
#include <cstring>
#include <fstream>
#include <map>
#include <set>
#include <sstream>
#include <string>

#include "post.h"
#include "zygisk.hpp"

#define TAG "CRT3D"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)

using zygisk::Api;
using zygisk::AppSpecializeArgs;
using zygisk::ServerSpecializeArgs;

// ---------------- socket helpers ----------------
static bool rd(int fd, void* buf, size_t n) {
    char* p = (char*)buf;
    while (n) {
        ssize_t k = read(fd, p, n);
        if (k <= 0) return false;
        p += k;
        n -= (size_t)k;
    }
    return true;
}
static bool wr(int fd, const void* buf, size_t n) {
    const char* p = (const char*)buf;
    while (n) {
        ssize_t k = write(fd, p, n);
        if (k <= 0) return false;
        p += k;
        n -= (size_t)k;
    }
    return true;
}

// ---------------- GOT hooking ----------------
typedef EGLBoolean (*SwapFn)(EGLDisplay, EGLSurface);
typedef EGLBoolean (*SwapDmgFn)(EGLDisplay, EGLSurface, EGLint*, EGLint);

static SwapFn o_swap = nullptr;
static SwapDmgFn o_swapKHR = nullptr;
static SwapDmgFn o_swapEXT = nullptr;

static EGLBoolean h_swap(EGLDisplay d, EGLSurface s) {
    crt_process(d, s);
    return o_swap(d, s);
}
static EGLBoolean h_swapKHR(EGLDisplay d, EGLSurface s, EGLint* r, EGLint n) {
    crt_process(d, s);
    return o_swapKHR(d, s, r, n);
}
static EGLBoolean h_swapEXT(EGLDisplay d, EGLSurface s, EGLint* r, EGLint n) {
    crt_process(d, s);
    return o_swapEXT(d, s, r, n);
}

struct HookDef {
    const char* sym;
    void* hook;
    void** orig;
};
static HookDef g_hooks[] = {
    {"eglSwapBuffers", (void*)h_swap, (void**)&o_swap},
    {"eglSwapBuffersWithDamageKHR", (void*)h_swapKHR, (void**)&o_swapKHR},
    {"eglSwapBuffersWithDamageEXT", (void*)h_swapEXT, (void**)&o_swapEXT},
};

#if defined(__LP64__)
typedef ElfW(Rela) RelT;
#define TAG_REL DT_RELA
#define TAG_RELSZ DT_RELASZ
#define R_SYM(i) ELF64_R_SYM(i)
#define R_TYPE(i) ELF64_R_TYPE(i)
static const unsigned R_GLOB = 1025, R_JUMP = 1026;
#else
typedef ElfW(Rel) RelT;
#define TAG_REL DT_REL
#define TAG_RELSZ DT_RELSZ
#define R_SYM(i) ELF32_R_SYM(i)
#define R_TYPE(i) ELF32_R_TYPE(i)
static const unsigned R_GLOB = 21, R_JUMP = 22;
#endif

static void install(void** slot, const HookDef& h, const char* lib) {
    if (*slot == h.hook) return;
    if (!*h.orig) *h.orig = *slot;
    long pg = sysconf(_SC_PAGESIZE);
    uintptr_t page = (uintptr_t)slot & ~(uintptr_t)(pg - 1);
    if (mprotect((void*)page, (size_t)pg, PROT_READ | PROT_WRITE) != 0) return;
    *slot = h.hook;
    LOGI("hooked %s in %s", h.sym, lib);
}

static void patch_table(uintptr_t base, uintptr_t tab, size_t sz, const ElfW(Sym)* symtab,
                        const char* strtab, const char* lib) {
    const RelT* r = (const RelT*)tab;
    size_t n = sz / sizeof(RelT);
    for (size_t i = 0; i < n; i++) {
        unsigned type = (unsigned)R_TYPE(r[i].r_info);
        if (type != R_GLOB && type != R_JUMP) continue;
        unsigned si = (unsigned)R_SYM(r[i].r_info);
        if (!si) continue;
        const char* name = strtab + symtab[si].st_name;
        for (auto& h : g_hooks) {
            if (strcmp(name, h.sym) == 0) install((void**)(base + r[i].r_offset), h, lib);
        }
    }
}

static int phdr_cb(dl_phdr_info* info, size_t, void* data) {
    auto* seen = (std::set<uintptr_t>*)data;
    const char* name = info->dlpi_name ? info->dlpi_name : "";
    if (!*name) return 0;
    if (strstr(name, "libhwui") || strstr(name, "libEGL") || strstr(name, "libGLES") ||
        strstr(name, "/linker") || strstr(name, "memfd:"))
        return 0;
    uintptr_t base = info->dlpi_addr;
    if (!seen->insert(base).second) return 0;

    const ElfW(Dyn)* dyn = nullptr;
    for (int i = 0; i < info->dlpi_phnum; i++)
        if (info->dlpi_phdr[i].p_type == PT_DYNAMIC)
            dyn = (const ElfW(Dyn)*)(base + info->dlpi_phdr[i].p_vaddr);
    if (!dyn) return 0;

    auto fix = [&](uintptr_t p) { return p < base ? p + base : p; };
    const char* strtab = nullptr;
    const ElfW(Sym)* symtab = nullptr;
    uintptr_t jmprel = 0, rel = 0;
    size_t pltsz = 0, relsz = 0;
    for (const ElfW(Dyn)* d = dyn; d->d_tag != DT_NULL; ++d) {
        switch (d->d_tag) {
            case DT_STRTAB: strtab = (const char*)fix(d->d_un.d_ptr); break;
            case DT_SYMTAB: symtab = (const ElfW(Sym)*)fix(d->d_un.d_ptr); break;
            case DT_JMPREL: jmprel = fix(d->d_un.d_ptr); break;
            case DT_PLTRELSZ: pltsz = d->d_un.d_val; break;
            case TAG_REL: rel = fix(d->d_un.d_ptr); break;
            case TAG_RELSZ: relsz = d->d_un.d_val; break;
            default: break;
        }
    }
    if (!strtab || !symtab) return 0;
    if (jmprel && pltsz) patch_table(base, jmprel, pltsz, symtab, strtab, name);
    if (rel && relsz) patch_table(base, rel, relsz, symtab, strtab, name);
    return 0;
}

static void* scan_thread(void*) {
    std::set<uintptr_t> seen;
    for (;;) {
        dl_iterate_phdr(phdr_cb, &seen);
        usleep(500 * 1000);
    }
    return nullptr;
}

// ---------------- companion (runs as root) ----------------
static std::string slurp(const char* path) {
    std::ifstream f(path);
    std::stringstream ss;
    ss << f.rdbuf();
    return ss.str();
}

static std::string trim(const std::string& s) {
    size_t b = s.find_first_not_of(" \t\r");
    if (b == std::string::npos) return "";
    size_t e = s.find_last_not_of(" \t\r");
    return s.substr(b, e - b + 1);
}

// config.txt layout:
//   keys before the first [section]  = defaults for every game
//   [name]                           = named profile (overrides defaults)
//   [apps]  package = profile        = enabled games and the profile each uses
static std::string build_config(const std::string& pkg) {
    std::istringstream in(slurp("/data/adb/crt3d/config.txt"));
    std::map<std::string, std::string> sections;  // "" = defaults
    std::string cur, line, appProfile;
    bool found = false;
    while (std::getline(in, line)) {
        std::string t = trim(line);
        if (t.empty() || t[0] == '#') continue;
        if (t[0] == '[') {
            size_t e = t.find(']');
            cur = (e == std::string::npos) ? "" : trim(t.substr(1, e - 1));
            continue;
        }
        if (cur == "apps") {
            size_t h = t.find('#');
            if (h != std::string::npos) t = trim(t.substr(0, h));
            std::string name = t, prof;
            size_t eq = t.find('=');
            if (eq != std::string::npos) {
                name = trim(t.substr(0, eq));
                prof = trim(t.substr(eq + 1));
            }
            if (name == pkg) {
                found = true;
                appProfile = prof;
            }
        } else {
            sections[cur] += t + "\n";
        }
    }
    if (!found) return "";
    std::string out = "enabled=1\n" + sections[""];
    if (!appProfile.empty()) {
        auto it = sections.find(appProfile);
        if (it != sections.end()) out += it->second;
    }
    return out;
}

static void companion_handler(int fd) {
    std::string out;
    uint32_t len = 0;
    if (rd(fd, &len, 4) && len > 0 && len < 256) {
        std::string pkg(len, '\0');
        if (rd(fd, &pkg[0], len)) out = build_config(pkg);
    }
    uint32_t n = (uint32_t)out.size();
    wr(fd, &n, 4);
    if (n) wr(fd, out.data(), n);
}

// ---------------- zygisk module ----------------
class CrtModule : public zygisk::ModuleBase {
public:
    void onLoad(Api* api, JNIEnv* env) override {
        this->api = api;
        this->env = env;
    }

    void preAppSpecialize(AppSpecializeArgs* args) override {
        const char* nice = args->nice_name ? env->GetStringUTFChars(args->nice_name, nullptr) : nullptr;
        if (nice) {
            std::string name(nice);
            env->ReleaseStringUTFChars(args->nice_name, nice);
            size_t c = name.find(':');
            if (c != std::string::npos) name.resize(c);
            int fd = api->connectCompanion();
            if (fd >= 0) {
                uint32_t len = (uint32_t)name.size();
                if (wr(fd, &len, 4) && wr(fd, name.data(), len)) {
                    uint32_t clen = 0;
                    if (rd(fd, &clen, 4) && clen > 0 && clen < 65536) {
                        cfg.resize(clen);
                        if (!rd(fd, &cfg[0], clen)) cfg.clear();
                    }
                }
                close(fd);
            }
        }
        if (cfg.empty()) api->setOption(zygisk::Option::DLCLOSE_MODULE_LIBRARY);
    }

    void postAppSpecialize(const AppSpecializeArgs*) override {
        if (cfg.empty()) return;
        crt_config(cfg);
        pthread_t t;
        if (pthread_create(&t, nullptr, scan_thread, nullptr) == 0) pthread_detach(t);
        LOGI("injected, scanning for EGL swap calls");
    }

    void preServerSpecialize(ServerSpecializeArgs*) override {
        api->setOption(zygisk::Option::DLCLOSE_MODULE_LIBRARY);
    }

private:
    Api* api = nullptr;
    JNIEnv* env = nullptr;
    std::string cfg;
};

REGISTER_ZYGISK_MODULE(CrtModule)
REGISTER_ZYGISK_COMPANION(companion_handler)
